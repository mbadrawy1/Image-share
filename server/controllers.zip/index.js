import "dotenv/config";
import express from "express";
import router from "./routes/index.js";
import cors from "cors";
import mongoose from "mongoose";
import { fileURLToPath } from "url";
import { dirname } from "path";
import path from "path";
import fs from "fs";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const port = process.env.PORT || 5000;
const mongoURI =
  process.env.MONGODB_URL || "mongodb://localhost:27017/imageshare";

const app = express();

// Ensure public/images directory exists
const imagesDir = path.join(__dirname, "public/images");
if (!fs.existsSync(imagesDir)) {
  fs.mkdirSync(imagesDir, { recursive: true });
}

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use("/images", express.static(path.join(__dirname, "public/images")));
app.use("/", router);

// Connect to MongoDB
try {
  await mongoose.connect(mongoURI);
  console.log("Connected to MongoDB successfully");

  app.listen(port, () => {
    console.log(`Server started on port ${port}`);
  });
} catch (error) {
  console.error("Error connecting to MongoDB:", error);
  process.exit(1);
}
