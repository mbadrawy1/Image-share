import express from "express";
import jwt from "jsonwebtoken"; // Add this import
import * as userController from "../controllers/userController.js";
import * as postController from "../controllers/postController.js"; // Modified import
import commentController from "../controllers/commentController.js";
import likeController from "../controllers/likeController.js";
import isLoggedIn from "../middlewares/authentication.js";
import {
  userValidationRules,
  updateUserValidationRules,
  postValidationRules,
  validate,
} from "../middlewares/validator.js";
import { upload, storeMetadata } from "../middlewares/upload.js";

const router = express.Router();

router.get("/", (req, res) => {
  res.json({
    message: "أهلًا بالعالم!",
  });
});

// User Routes
router.post(
  "/account/register",
  userValidationRules(),
  validate,
  userController.register
);
// Add this test route
router.get("/test-auth", (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader) {
      return res.status(401).json({ message: "No token provided" });
    }

    // Extract token
    const token = authHeader.startsWith("Bearer ")
      ? authHeader.slice(7)
      : authHeader;

    // Verify with just the JWT library
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    res.json({
      success: true,
      message: "Token verified",
      user: decoded,
    });
  } catch (err) {
    res.status(401).json({
      error: err.name,
      message: err.message,
    });
  }
});
router.post("/account/login", userController.login);
router.get("/account/profile", isLoggedIn, userController.getProfile);
router.put(
  "/account/profile/upload-photo",
  upload.single("avatar"), // Specify field name here
  storeMetadata, // Add metadata handling
  isLoggedIn,
  userController.uploadUserPhoto
);
router.put(
  "/account/profile/update",
  updateUserValidationRules(),
  validate,
  isLoggedIn,
  userController.updateProfile
);

// Post Routes
router.post(
  "/posts/create",
  upload.array("postImg", 5), // Handle multiple files
  postValidationRules(),
  validate,
  isLoggedIn,
  storeMetadata, // Optional: Add if metadata is needed for posts
  postController.newPost
);
router.get("/posts", isLoggedIn, postController.getAllPosts);
router.get("/posts/:postId", isLoggedIn, postController.getPost);
router.get("/my-posts", isLoggedIn, postController.getMyAllPosts);
router.get("/my-posts/:postId", isLoggedIn, postController.getMyPost);
router.put(
  "/my-posts/:postId/update",
  postValidationRules(),
  validate,
  isLoggedIn,
  postController.updateMyPost
);

router.delete("/my-posts/delete", isLoggedIn, (req, res) => {
  // Set the params.postId from the body
  req.params.postId = req.body.postId;
  postController.deleteMyPost(req, res);
});
// Comment Routes
router.post(
  "/posts/:postId/create-comment",
  isLoggedIn,
  commentController.createComment
);
router.get(
  "/posts/:postId/get-comments",
  isLoggedIn,
  commentController.getComment
);

// Like Routes
router.put("/posts/:postId/like", isLoggedIn, likeController.like);
router.get("/posts/:postId/like-count", isLoggedIn, likeController.likeCount);

export default router;
