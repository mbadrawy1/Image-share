import Comment from "../models/comment.js";

const createComment = async (req, res) => {
  const { text } = req.body;
  try {
    const comment = new Comment({
      text,
      post: req.params.postId,
      user: req.currentUser.id,
    });
    await comment.save();
    res.status(200).json({ message: "تم إضافة التعليق" });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};

const getComment = async (req, res) => {
  try {
    const comments = await Comment.find({ post: req.params.postId })
      .populate("user", "-email -password")
      .exec();
    res.status(200).json(comments);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};

export default { createComment, getComment }; // Default export as an object
