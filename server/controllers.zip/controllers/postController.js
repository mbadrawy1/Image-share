import Post from "../models/post.js";
import User from "../models/user.js";
import Comment from "../models/comment.js";
import Like from "../models/like.js";
import fs from "fs/promises";
import PostImage from "../models/post_image.js";
// Make sure to import this

export const newPost = async (req, res) => {
  const { title, contents, steps, country, region } = req.body;
  try {
    // 1. Create the Post document first (without images)
    const post = new Post({
      title,
      contents,
      steps,
      country,
      region,
      user: req.currentUser.id,
      images: [], // Start with empty images array
    });

    await post.save();

    // 2. Create PostImage documents for each uploaded file
    const imagePromises = req.files.map(async (file) => {
      const imagePath = "/public/images/" + file.filename;

      // Create and save PostImage document
      const postImage = new PostImage({
        img_uri: imagePath,
        post: post._id,
      });

      await postImage.save();

      // Return the saved image's ID
      return postImage._id;
    });

    // 3. Wait for all PostImage documents to be created
    const imageIds = await Promise.all(imagePromises);

    // 4. Update the Post with the image references
    post.images = imageIds;
    await post.save();

    // 5. Update user's posts array
    await User.findByIdAndUpdate(req.currentUser.id, {
      $push: { posts: post._id },
    });

    res.status(200).json({
      message: "تم إضافة منشور جديد",
      post: post,
    });
  } catch (e) {
    console.error("Post creation error:", e);
    res.status(500).json({ error: e.message });
  }
};

export const getAllPosts = async (req, res) => {
  try {
    const posts = await Post.find()
      .populate({
        path: "user",
        select: "-password -email",
      })
      .sort({ createdAt: -1 });

    res.status(200).json(posts);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};

export const getPost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.postId).populate({
      path: "user",
      select: "-password -email",
    });

    if (!post) return res.status(404).json({ message: "المنشور غير موجود" });

    res.status(200).json(post);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};

export const getMyAllPosts = async (req, res) => {
  try {
    const posts = await Post.find({ user: req.currentUser.id }).sort({
      createdAt: -1,
    });

    res.status(200).json(posts);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};

export const getMyPost = async (req, res) => {
  try {
    const post = await Post.findOne({
      _id: req.params.postId,
      user: req.currentUser.id,
    });

    if (!post) return res.status(404).json({ message: "المنشور غير موجود" });

    res.status(200).json(post);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};

export const updateMyPost = async (req, res) => {
  const { title, contents, steps } = req.body;
  try {
    const post = await Post.findOneAndUpdate(
      {
        _id: req.params.postId,
        user: req.currentUser.id,
      },
      { title, contents, steps },
      { new: true, runValidators: true }
    );

    if (!post) return res.status(404).json({ message: "المنشور غير موجود" });

    res.status(200).json({
      message: "تم التعديل على بيانات المنشور",
      post,
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};

export const deleteMyPost = async (req, res) => {
  try {
    const post = await Post.findOne({
      _id: req.params.postId,
      user: req.currentUser.id,
    });

    if (!post) return res.status(404).json({ message: "المنشور غير موجود" });

    // First get all image documents to access their paths
    const postImages = await PostImage.find({ _id: { $in: post.images } });

    // Delete the actual image files
    await Promise.all(
      postImages.map(async (postImage) => {
        try {
          await fs.unlink("." + postImage.img_uri);
        } catch (fileError) {
          console.log(
            `Failed to delete file: ${postImage.img_uri}`,
            fileError.message
          );
          // Continue with deletion even if file is missing
        }
      })
    );

    // Delete the PostImage documents
    await PostImage.deleteMany({ _id: { $in: post.images } });

    // Now delete the post itself
    await Post.findOneAndDelete({
      _id: req.params.postId,
      user: req.currentUser.id,
    });

    // Delete related comments and likes
    await Comment.deleteMany({ post: post._id });
    await Like.deleteMany({ post: post._id });

    // Remove from user's posts array
    await User.findByIdAndUpdate(req.currentUser.id, {
      $pull: { posts: post._id },
    });

    res.status(200).json({ message: "تم حذف منشورك" });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};
