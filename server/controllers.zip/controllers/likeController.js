import mongoose from "mongoose";
import Like from "../models/like.js";

const like = async (req, res) => {
  try {
    const { postId } = req.params;
    const userId = req.currentUser.id;
    console.log(`Adding/removing like - postId: ${postId}, userId: ${userId}`);

    // Convert postId to ObjectId
    const postObjectId = new mongoose.Types.ObjectId(postId);
    const userObjectId = new mongoose.Types.ObjectId(userId);

    const userLiked = await Like.findOne({
      user: userObjectId,
      post: postObjectId,
    });
    console.log("User already liked:", !!userLiked);

    if (userLiked) {
      await Like.deleteOne({ user: userObjectId, post: postObjectId });
      res.status(200).json({ message: "تم حذف الإعجاب" });
    } else {
      const like = new Like({
        user: userObjectId,
        post: postObjectId,
      });
      const savedLike = await like.save();
      console.log("Saved like:", savedLike);
      res.status(200).json({ message: "تم إضافة الإعجاب", like: savedLike });
    }
  } catch (e) {
    console.error("Error in like function:", e);
    res.status(500).json({ error: e.message });
  }
};

const likeCount = async (req, res) => {
  try {
    const { postId } = req.params;
    const userId = req.currentUser.id;
    console.log(`Counting likes - postId: ${postId}, userId: ${userId}`);

    // Convert postId to ObjectId
    const postObjectId = new mongoose.Types.ObjectId(postId);
    const userObjectId = new mongoose.Types.ObjectId(userId);

    const likes = await Like.countDocuments({ post: postObjectId });
    console.log(`Found ${likes} likes for post ${postId}`);

    const userLiked = await Like.findOne({
      user: userObjectId,
      post: postObjectId,
    });
    console.log("User liked this post:", !!userLiked);

    res.status(200).json({ likes, userLiked: !!userLiked });
  } catch (e) {
    console.error("Error in likeCount function:", e);
    res.status(500).json({ error: e.message });
  }
};

export default { like, likeCount };
